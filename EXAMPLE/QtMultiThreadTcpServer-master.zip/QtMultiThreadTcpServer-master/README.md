# QtMultiThreadTcpServer
A multi-thread tcp server base on Qt
