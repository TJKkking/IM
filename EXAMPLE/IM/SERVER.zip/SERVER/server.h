#ifndef SERVER_H
#define SERVER_H

#include <QTcpServer>

#include "serverthread.h"

class Dialog;

class Server : public QTcpServer
{
    Q_OBJECT
public:
    explicit Server(QObject *parent = Q_NULLPTR);
    ~Server();

private:
    void incomingConnection(qintptr sockDesc);

private slots:
    void clientDisconnected(int sockDesc);

private:
    Dialog *m_dialog;

    QList<int> m_socketList;
    //socket_list= newQList<QTcpSocket*>;

};

#endif // SERVER_H
